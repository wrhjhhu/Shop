import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, Coffee, Award } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Story</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Founded in 2010, Brew Haven has been serving premium coffee and creating
            memorable experiences for our community.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <img
              src="https://images.unsplash.com/photo-1516880711640-ef7db81be3e1"
              alt="Our barista team"
              className="rounded-lg shadow-lg"
            />
          </motion.div>

          <div className="grid gap-6">
            {[
              {
                icon: Coffee,
                title: "Premium Beans",
                description: "Sourced from sustainable farms worldwide",
              },
              {
                icon: Clock,
                title: "Fresh Roasts",
                description: "Roasted daily in small batches",
              },
              {
                icon: Award,
                title: "Expert Baristas",
                description: "Trained to craft the perfect cup",
              },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardContent className="flex items-center gap-4 p-6">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <item.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-1">{item.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
