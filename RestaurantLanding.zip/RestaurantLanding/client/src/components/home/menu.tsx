import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const MENU_ITEMS = [
  {
    name: "Signature Latte",
    price: "$4.50",
    description: "House-made vanilla syrup, espresso, steamed milk",
    image: "https://images.unsplash.com/photo-1445077100181-a33e9ac94db0",
    badge: "Popular",
  },
  {
    name: "Artisan Pastries",
    price: "$3.75",
    description: "Freshly baked croissants and danishes",
    image: "https://images.unsplash.com/photo-1523861706897-9458a5d5be0c",
  },
  {
    name: "Pour Over",
    price: "$3.50",
    description: "Single-origin coffee, hand-poured to perfection",
    image: "https://images.unsplash.com/photo-1455146106369-1e31beb07fce",
  },
];

export default function Menu() {
  return (
    <section id="menu" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Menu</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover our carefully curated selection of coffee and treats
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {MENU_ITEMS.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-48 object-cover"
                />
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{item.name}</CardTitle>
                    <span className="font-semibold text-primary">{item.price}</span>
                  </div>
                  {item.badge && (
                    <Badge variant="secondary" className="w-fit">
                      {item.badge}
                    </Badge>
                  )}
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
