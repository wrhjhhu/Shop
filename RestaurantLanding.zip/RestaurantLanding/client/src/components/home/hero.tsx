import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Coffee } from "lucide-react";

export default function Hero() {
  return (
    <section className="min-h-screen relative flex items-center">
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7)), url(https://images.unsplash.com/photo-1521017432531-fbd92d768814)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      
      <div className="container mx-auto px-4 z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-2xl"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Where Every Cup Tells a Story
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8">
            Experience the perfect blend of artisanal coffee and cozy atmosphere
            at Brew Haven. Your daily escape awaits.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="gap-2">
              <Coffee className="h-5 w-5" />
              View Our Menu
            </Button>
            <Button size="lg" variant="outline" className="bg-white/10">
              Book a Table
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
