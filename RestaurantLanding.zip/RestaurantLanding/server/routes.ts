import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTableReservationSchema, insertOrderSchema, insertOrderItemSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Table Reservations
  app.post("/api/reservations", async (req, res) => {
    try {
      const data = insertTableReservationSchema.parse(req.body);
      const reservation = await storage.createReservation(data);
      res.status(201).json(reservation);
    } catch (error) {
      console.error("Reservation creation error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          message: "Failed to create reservation",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
  });

  app.get("/api/reservations/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid reservation ID" });
      }

      const reservation = await storage.getReservation(id);
      if (!reservation) {
        return res.status(404).json({ message: "Reservation not found" });
      }
      res.json(reservation);
    } catch (error) {
      console.error("Get reservation error:", error);
      res.status(500).json({ message: "Failed to get reservation" });
    }
  });

  app.get("/api/reservations/email/:email", async (req, res) => {
    try {
      const reservations = await storage.getReservationsByEmail(req.params.email);
      res.json(reservations);
    } catch (error) {
      console.error("Get reservations by email error:", error);
      res.status(500).json({ message: "Failed to get reservations" });
    }
  });

  app.patch("/api/reservations/:id/status", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid reservation ID" });
      }

      const status = z.enum(["pending", "confirmed", "cancelled"]).parse(req.body.status);
      const reservation = await storage.updateReservationStatus(id, status);
      res.json(reservation);
    } catch (error) {
      console.error("Update reservation status error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid status value" });
      } else {
        res.status(500).json({ message: "Failed to update reservation status" });
      }
    }
  });

  // Orders
  app.post("/api/orders", async (req, res) => {
    try {
      if (!req.body.order || !req.body.items) {
        return res.status(400).json({ message: "Missing order or items data" });
      }

      const orderData = insertOrderSchema.parse(req.body.order);
      const itemsData = z.array(insertOrderItemSchema).parse(req.body.items);

      const order = await storage.createOrder(orderData, itemsData);
      res.status(201).json(order);
    } catch (error) {
      console.error("Order creation error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      } else {
        res.status(500).json({ 
          message: "Failed to create order",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }

      const order = await storage.getOrderWithItems(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      console.error("Get order error:", error);
      res.status(500).json({ message: "Failed to get order" });
    }
  });

  app.get("/api/orders/email/:email", async (req, res) => {
    try {
      const orders = await storage.getOrdersByEmail(req.params.email);
      res.json(orders);
    } catch (error) {
      console.error("Get orders by email error:", error);
      res.status(500).json({ message: "Failed to get orders" });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }

      const status = z.enum(["pending", "preparing", "ready", "delivered"]).parse(req.body.status);
      const order = await storage.updateOrderStatus(id, status);
      res.json(order);
    } catch (error) {
      console.error("Update order status error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid status value" });
      } else {
        res.status(500).json({ message: "Failed to update order status" });
      }
    }
  });

  // Menu Items
  app.get("/api/menu-items", async (req, res) => {
    const menuItems = await storage.getAllMenuItems();
    res.json(menuItems);
  });

  app.get("/api/menu-items/:id", async (req, res) => {
    const menuItem = await storage.getMenuItem(Number(req.params.id));
    if (!menuItem) {
      return res.status(404).json({ message: "Menu item not found" });
    }
    res.json(menuItem);
  });

  const httpServer = createServer(app);
  return httpServer;
}