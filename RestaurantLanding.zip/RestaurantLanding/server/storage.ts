import { 
  orders, orderItems, tableReservations,
  type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem,
  type TableReservation, type InsertTableReservation,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Table Reservation methods
  createReservation(reservation: InsertTableReservation): Promise<TableReservation>;
  getReservation(id: number): Promise<TableReservation | undefined>;
  updateReservationStatus(id: number, status: string): Promise<TableReservation>;
  getReservationsByEmail(email: string): Promise<TableReservation[]>;

  // Order methods
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  getOrder(id: number): Promise<Order | undefined>;
  getOrderWithItems(id: number): Promise<{ order: Order; items: OrderItem[] } | undefined>;
  updateOrderStatus(id: number, status: string): Promise<Order>;
  getOrdersByEmail(email: string): Promise<Order[]>;
}

export class DatabaseStorage implements IStorage {
  // Table Reservation methods
  async createReservation(reservation: InsertTableReservation): Promise<TableReservation> {
    try {
      const [newReservation] = await db
        .insert(tableReservations)
        .values(reservation)
        .returning();
      return newReservation;
    } catch (error) {
      console.error("Error creating reservation:", error);
      throw error;
    }
  }

  async getReservation(id: number): Promise<TableReservation | undefined> {
    try {
      const [reservation] = await db
        .select()
        .from(tableReservations)
        .where(eq(tableReservations.id, id));
      return reservation;
    } catch (error) {
      console.error("Error getting reservation:", error);
      throw error;
    }
  }

  async updateReservationStatus(id: number, status: string): Promise<TableReservation> {
    try {
      const [reservation] = await db
        .update(tableReservations)
        .set({ status })
        .where(eq(tableReservations.id, id))
        .returning();
      return reservation;
    } catch (error) {
      console.error("Error updating reservation status:", error);
      throw error;
    }
  }

  async getReservationsByEmail(email: string): Promise<TableReservation[]> {
    try {
      return db
        .select()
        .from(tableReservations)
        .where(eq(tableReservations.email, email))
        .orderBy(desc(tableReservations.createdAt));
    } catch (error) {
      console.error("Error getting reservations by email:", error);
      throw error;
    }
  }

  // Order methods
  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    try {
      return await db.transaction(async (tx) => {
        const [newOrder] = await tx
          .insert(orders)
          .values(order)
          .returning();

        if (items.length > 0) {
          const orderItemsWithId = items.map(item => ({
            ...item,
            orderId: newOrder.id,
          }));

          await tx.insert(orderItems).values(orderItemsWithId);
        }

        return newOrder;
      });
    } catch (error) {
      console.error("Error creating order:", error);
      throw error;
    }
  }

  async getOrder(id: number): Promise<Order | undefined> {
    try {
      const [order] = await db
        .select()
        .from(orders)
        .where(eq(orders.id, id));
      return order;
    } catch (error) {
      console.error("Error getting order:", error);
      throw error;
    }
  }

  async getOrderWithItems(id: number): Promise<{ order: Order; items: OrderItem[] } | undefined> {
    try {
      const order = await this.getOrder(id);
      if (!order) return undefined;

      const items = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.orderId, id));

      return { order, items };
    } catch (error) {
      console.error("Error getting order with items:", error);
      throw error;
    }
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    try {
      const [order] = await db
        .update(orders)
        .set({ status })
        .where(eq(orders.id, id))
        .returning();
      return order;
    } catch (error) {
      console.error("Error updating order status:", error);
      throw error;
    }
  }

  async getOrdersByEmail(email: string): Promise<Order[]> {
    try {
      return db
        .select()
        .from(orders)
        .where(eq(orders.email, email))
        .orderBy(desc(orders.createdAt));
    } catch (error) {
      console.error("Error getting orders by email:", error);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();